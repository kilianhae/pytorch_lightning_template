"""
Any functions needed for plotting are defined here.
"""